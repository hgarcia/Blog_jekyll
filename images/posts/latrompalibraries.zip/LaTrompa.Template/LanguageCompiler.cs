using System;

namespace LaTrompa.Templating
{
    /// <summary>
    /// The language compilers need to inherit from this class
    /// </summary>
    public abstract class LanguageCompiler : TemplateCompiler
    {
        protected abstract void LoadTemplateFromMethod();
        protected abstract void LoadTemplateFromVariable();
    }
}
