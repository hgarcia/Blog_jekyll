using System;
using System.IO;

namespace LaTrompa.Templating
{
    /// <summary>
    /// Base class for the template compilers
    /// </summary>
    public abstract class TemplateCompiler : ITemplateCompilable
    {
        private string _methodName = string.Empty;
        private string _variableName = string.Empty;
        private string _path = string.Empty;
        private string _templateString = string.Empty;
        #region ICompilable Members

        /// <summary>
        /// Fully qualified Method name that returns the template
        /// </summary>
        public string MethodName
        {
            get
            {
                return _methodName;
            }
            set
            {
                _methodName = value;
            }
        }

        /// <summary>
        /// Variable name that holds the template
        /// </summary>
        public string VariableName
        {
            get
            {
                return _variableName;
            }
            set
            {
                _variableName = value;
            }
        }
        
        /// <summary>
        /// Sets Gets the path to the template
        /// </summary>
        public string Path
        {
            get
            {
                return _path;
            }
            set
            {
                _path = value;
            }
        }

        /// <summary>
        /// Sets Gets the compiled template (the template string only).
        /// </summary>
        public string TemplateString
        {
            set 
            { 
                _templateString = value; 
            }
            get
            {
                return _templateString;
            }
        }

        /// <summary>
        /// Compile the template getting just the template string
        /// </summary>
        /// <returns>The template string</returns>
        public abstract string Compile();
        #endregion

        #region Common Implementation

        /// <summary>
        /// Loads the template from the text file passed in the Path property
        /// </summary>
        protected void LoadTemplate() 
        {
            StreamReader sr = File.OpenText(this.Path);
            this.TemplateString = sr.ReadToEnd();
        }
        
        #endregion

    }
}
