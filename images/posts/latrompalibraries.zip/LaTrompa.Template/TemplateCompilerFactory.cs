using System;

namespace LaTrompa.Templating
{
    public class TemplateCompilerFactory
    {
        /// <summary>
        /// Creates a TemplateCompiler appropiate for files with the given extention
        /// </summary>
        /// <param name="fileExtention">Extention of the file containing the tempalte</param>
        /// <returns>A class that implements ICompilable</returns>
        public static ITemplateCompilable Create(string fileExtention)
        {
            return LaTrompa.DI.DependencySettings.GetClassInstance<ITemplateCompilable>("templateCompiler" + fileExtention);
        }
    }
}
