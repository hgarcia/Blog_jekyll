using System;

namespace LaTrompa.Templating
{
    /// <summary>
    /// All the language compilers need to implement this interface
    /// </summary>
    public interface ITemplateCompilable
    {
        string Path { get; set;}
        string TemplateString { get; set; }
        string MethodName { get; set;}
        string VariableName { get; set;}

        string Compile();
    }
}
