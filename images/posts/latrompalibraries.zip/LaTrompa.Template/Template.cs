using System;
using System.Collections;
using System.Text;
using System.Reflection;
using System.Text.RegularExpressions;

namespace LaTrompa.Templating
{
    /// <summary>
    /// This is the template processing class
    /// </summary>
    public class Template
    {
        private StringBuilder _internalTemplate = new StringBuilder();
        private bool _processFields = false;
        private bool _processProperties = true;
        private string _regexPattern = "#{.*?}";

        /// <summary>
        /// String based template processor
        /// </summary>
        /// <param name="template">The String with the template</param>
        public Template(String template) 
        {
            this._internalTemplate.Append(template);
        }

        /// <summary>
        /// String based template processor
        /// </summary>
        /// <param name="template">The String with the template</param>
        /// <param name="regExPattern">A cusotm regular expression pattern to apply to the template</param>
        public Template(String template, string regExPattern)
        {
            this._internalTemplate.Append(template);
            this._regexPattern = regExPattern;
        }

        /// <summary>
        /// Compiler based template processor
        /// </summary>
        /// <param name="templateCompiler">A template compiler</param>
        public Template(ITemplateCompilable templateCompiler)
        {
            _internalTemplate.Append(templateCompiler.Compile());
        }

        /// <summary>
        /// Compiler based template processor
        /// </summary>
        /// <param name="templateCompiler">A template compiler</param>
        /// <param name="regExPattern">A cusotm regular expression pattern to apply to the template</param> 
        public Template(ITemplateCompilable templateCompiler, string regExPattern)
        {
            this._internalTemplate.Append(templateCompiler.Compile());
            this._regexPattern = regExPattern;
        }

        /// <summary>
        /// IEnumarable template, process a collection and apply the template to each item of the collection, usefull to write, lista and tables.
        /// </summary>
        /// <param name="list">The object, needs to implement IEnumerable</param>
        /// <param name="processFields">If <c>true</c> read all Fields for the object</param>
        /// <param name="processProperties">If <c>true</c> read all the Properties for the object</param>
        /// <returns>String containing the content of the collection formated with the template</returns>
        public string Process(IEnumerable list, bool processFields, bool processProperties) 
        {
            this._processFields = processFields;
            this._processProperties = processProperties;

            string cachedTemplate = _internalTemplate.ToString();
            StringBuilder sb = new StringBuilder();
            MatchCollection mc = GetMatchCollection();

            foreach (Object item in list)
            {
                _internalTemplate.Remove(0, _internalTemplate.Length);
                _internalTemplate.Append(cachedTemplate);

                if (this._processFields)
                {
                    ProcessFields(item, mc);
                }

                if (this._processProperties)
                {
                    ProcessProperties(item, mc);
                }

                sb.Append(_internalTemplate.ToString());
            }
            return sb.ToString();
        }

        /// <summary>
        /// Process a template with data from a single object, use the propeties of the object as the data containers.
        /// </summary>
        /// <param name="item">The object with the data</param>
        /// <param name="processFields">If <c>true</c> read all Fields for the object</param>
        /// <param name="processProperties">If <c>true</c> read all the Properties for the object</param>
        /// <returns>String with the processed template</returns>
        public string Process(Object item, bool processFields, bool processProperties)
        {
            this._processFields = processFields;
            this._processProperties = processProperties;

            MatchCollection mc = GetMatchCollection();
            if (this._processFields)
            {
                ProcessFields(item, mc);
            }
            if (this._processProperties)
            {
                ProcessProperties(item, mc);
            }

            return _internalTemplate.ToString();
        }

        /// <summary>
        /// Check if the object has Fields that correspond to the names of the matching template variables and replace the variables with a value.ToString() of the field
        /// </summary>
        /// <param name="item">The object to get the fields from</param>
        /// <param name="mc">A MatchCollection</param>
        private void ProcessFields(object item, MatchCollection mc)
        {
            foreach (Match m in mc)
            {
                this._internalTemplate.Replace(m.Value, GetPropertyValue(item, m.Value));
            }
        }

        /// <summary>
        /// Check if the object has Properties that correspond to the names of the matching template variables and replace the variables with a value.ToString() of the field
        /// </summary>
        /// <param name="item">The object to get the properties from</param>
        /// <param name="mc">A MatchCollection</param>
        private void ProcessProperties(object item, MatchCollection mc)
        {
            foreach (Match m in mc)
            {
                this._internalTemplate.Replace(m.Value, GetPropertyValue(item, m.Value));
            }
        }

        /// <summary>
        /// Returns the value.ToString() of a field in an object
        /// </summary>
        /// <param name="item">The object</param>
        /// <param name="fieldName">The field name</param>
        /// <returns> object.Field.ToString() </returns>
        private string GetFieldValue(object item, string fieldName)
        {
            string[] name = fieldName.Replace("#{", "").Replace("}", "").Split('.');
            try
            {
                for (int i = 0; i < name.Length; i++)
                {
                    item = item.GetType().GetField(name[i]).GetValue(item);
                }
                return item.ToString();
            }
            catch (Exception e)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Returns the value.ToString() of a property in an object
        /// </summary>
        /// <param name="item">The object</param>
        /// <param name="fieldName">The property name</param>
        /// <returns> object.Property.ToString() </returns>
        private string GetPropertyValue(object item, string fieldName)
        {
            string[] name = fieldName.Replace("#{", "").Replace("}", "").Split('.');
            try
            {
                for (int i = 0; i < name.Length; i++)
                {
                    item = item.GetType().GetProperty(name[i]).GetValue(item,null);
                }
                return item.ToString();
            }
            catch (Exception e)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Apply a RegEx on the template and returns a MatchCollection
        /// </summary>
        /// <returns>MatchCollection</returns>
        private MatchCollection GetMatchCollection()
        {
            return Regex.Matches(this._internalTemplate.ToString(), this._regexPattern, RegexOptions.None);
        }
    } 
}
