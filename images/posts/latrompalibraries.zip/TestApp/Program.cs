﻿using System;
using System.Collections.Generic;
using System.Text;
using LaTrompa.Templating;

namespace TestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "This is some text #{testClass} I 'm also testing my #{regex} skills\n";
            s += "And I also #{testingmore.some} collection #{three.ina.thisa}";
            s += "Can I do this more complicate\n?";

            Template temp = new Template(s);

            string r = temp.Process(new { testClass = "that I'm using to test the template class.\n", regex = "\"regular expression\"", testingmore = new { some = "checking if I can pass a" }, three = new {ina= new {thisa= "or better said infinite number of objects in the properties.\n"} } }, true, true);
            Console.Write(r);
        }
    }
}
