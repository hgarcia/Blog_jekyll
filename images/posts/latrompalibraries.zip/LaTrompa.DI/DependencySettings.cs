using System;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using System.Runtime.Remoting;

namespace LaTrompa.DI
{
    public static class DependencySettings
    {
        private static string _xpathTemplate = "//dependencies/dependency[@key='{0}']";
        
        /// <summary>
        /// Returns the String with the qualified name of the Assembly and the class
        /// </summary>
        /// <param name="key">The key of the dependency key</param>
        /// <returns>String with the fully qualified Class name</returns>
        public static string GetAssemblyName(string key)
        {
            try
            {
                string xpath = string.Format(_xpathTemplate, key);
                XmlDocument dom = new XmlDocument();
                dom.Load("dependencies.xml");
                XmlNodeList nodes = dom.SelectNodes(xpath);

                if (nodes.Count <= 0)
                {
                    throw new DependencyNoKeyException(key);
                }

                if (nodes.Count > 1)
                {
                    throw new DependencyAmbiguosKeyException(key);
                }

                return nodes[0].Attributes["assemblyName"].InnerText;

            }
            catch (FileNotFoundException fnf)
            {
                throw new DependencyFileNotFoundException(fnf);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Returns the String with the qualified name of the Assembly and the class
        /// </summary>
        /// <param name="key">The key of the dependency key</param>
        /// <returns>String with the fully qualified Class name</returns>
        public static string GetClassName(string key)
        {
            try
            {
                string xpath = string.Format(_xpathTemplate, key);
                XmlDocument dom = new XmlDocument();
                dom.Load("dependencies.xml");
                XmlNodeList nodes = dom.SelectNodes(xpath);

                if (nodes.Count <= 0)
                {
                    throw new DependencyNoKeyException(key);
                }

                if (nodes.Count > 1)
                {
                    throw new DependencyAmbiguosKeyException(key);
                }

                return nodes[0].Attributes["className"].InnerText;

            }
            catch (FileNotFoundException fnf)
            {
                throw new DependencyFileNotFoundException(fnf);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Returns an object of type T
        /// </summary>
        /// <typeparam name="T">The type or interface of the object to return</typeparam>
        /// <param name="key">The key of the dependency key</param>
        /// <returns>An Object of type T</returns>
        public static T GetClassInstance<T>(string key)
        {
            ObjectHandle oh = Activator.CreateInstance(GetAssemblyName(key),GetClassName(key));
            return (T)oh.Unwrap();
        }

    }
}
