using System;
using System.Collections.Generic;
using System.Text;

namespace LaTrompa.DI
{
    public class DependencyFileNotFoundException : Exception
    {
        public DependencyFileNotFoundException(Exception e) : base("You need to include a depedencies.xml file in your solution. " + e.Message) { } 
    }

    public class DependencyNoKeyException : Exception
    {
        public DependencyNoKeyException(string key) : base("There are no dependency elements with the key: " + key + ".") { }
    }

    public class DependencyAmbiguosKeyException : Exception
    {
        public DependencyAmbiguosKeyException(string key) : base("The key: " + key + " returns more than one dependency, you should only have one dependency per key.") { }
    }
}
