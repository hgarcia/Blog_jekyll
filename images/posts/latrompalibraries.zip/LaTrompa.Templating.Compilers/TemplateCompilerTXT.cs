using System;
using LaTrompa.Templating;

namespace LaTrompa.Templating.Compilers
{
    /// <summary>
    /// TemplateCompiler implementation for pure txt files.
    /// </summary>
   public class TemplateCompilerTXT : TemplateCompiler
    {
        /// <summary>
        /// Loads the txt file and return all its content.
        /// </summary>
        /// <returns>The content for the txt file</returns>
        public override string Compile()
        {
            this.LoadTemplate();
            return this.TemplateString;
        }
    }
}
