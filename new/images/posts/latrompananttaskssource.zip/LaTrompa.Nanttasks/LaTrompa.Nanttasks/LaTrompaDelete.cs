using System;
using System.IO;
using NAnt.Core;
using NAnt.Core.Attributes;


namespace LaTrompa.NantTasks
{
    [TaskName("forceDelete")]
    public class LaTrompaDelete : Task
    {
        #region Private Instance Fields

        private string _dir;
        private bool _deleting = true;
        private int _failSafe = 1;
        private int _attemps = 1;

        #endregion Private Instance Fields

        #region Public Instance Properties

        [TaskAttribute("dir", Required = true)]
        public string Dir
        {
            get { return this._dir; }
            set { this._dir = value; }
        }
        [TaskAttribute("attemps", Required = false)]
        public int Attemps
        {
            get { return this._attemps; }
            set { this._attemps = value; }
        }

        #endregion Public Instance Properties

        #region Override implementation of Task

        protected override void ExecuteTask()
        {
            Log(Level.Info, "Starts deleting");
            while (this._deleting && this._failSafe < (this._attemps+1))
            {
                this.DeleteFiles();
            }
            Log(Level.Info, "Ends deleting");
        }

        private void DeleteFiles()
        {
            try
            {
                Log(Level.Info, "Deleting: Attemp # " + this._failSafe.ToString() );
                Directory.Delete(this._dir, true);
                this._deleting = false;
            }
            catch (Exception e)
            {
                Log(Level.Info, e.Message);
                this._failSafe++;
            }
        }
        #endregion Override implementation of Task
    }
}
